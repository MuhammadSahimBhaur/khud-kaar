import React from 'react';

const AdminDashboard = () => {
  return <div>Hello</div>;
};

export default AdminDashboard;
