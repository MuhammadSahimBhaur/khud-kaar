//SERVER ROUTES
export const USER_SERVER = '/api/users';
export const ADMIN_SERVER = '/api/admin';
// export const
